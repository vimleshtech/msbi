
select * from employee 

select * from employee 


select * into emp_new from employee 

select * into emp1 from employee where eid<4

alter table emp_new
drop column edob

alter table emp_new
add sal int

update emp_new
set sal = 145666
where eid > 7

select * from [dbo].[Merge_out]


select * from [dbo].[Merge_data]

1 
1  

select * from [dbo].[import_data] 

delete from [dbo].[import_data] 
where  file_path is null 


select * from union_data

backup database harinder to disk='D:\prag\harinder.dmp'